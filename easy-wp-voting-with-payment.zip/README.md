# easy-wp-voting-with-payment
Easy Wp Voting with Payment Plugin is a wordpress plugin that allow user to pay before voting
